import torch
Tensor = torch.Tensor
import math
import os
import torch.nn.functional as F
os.environ['CUDA_VISIBLE_DEVICES'] = '1'

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

def sym_norm_adj(adj):
    degree = adj.sum(dim=1)
    D_inv_sqrt = torch.pow(degree, -0.5)
    D_inv_sqrt[torch.isinf(D_inv_sqrt)] = 0.
    D = torch.diag(D_inv_sqrt).float()
    L = torch.matmul(torch.matmul(D, adj.float()), D)
    # print(L)
    I = torch.eye(adj.size(0))
    A_sym_norm = L + I.to(device)

    return A_sym_norm




# class GCN_Layer(torch.nn.Module):
#     def __init__(self, hidden_size1, hidden_size2, dropout=0.5):
#
#         super(GCN_Layer, self).__init__()
#         self.device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
#         self.hidden_size1 = hidden_size1
#         self.hidden_size2 = hidden_size2
#         self.W = torch.nn.Parameter(torch.FloatTensor(self.hidden_size1, self.hidden_size2))
#         self.dropout = dropout
#         self.reset_parameters()
#
#
#     def reset_parameters(self):
#         for weight in self.parameters():
#             stdv = 1. / math.sqrt(weight.size(0))
#             torch.nn.init.uniform_(weight, -stdv, stdv)
#
#
#     def forward(self, input, adj):
#         input = F.dropout(input, self.dropout, training=self.training)
#         support = torch.matmul(input, self.W.to(self.device))
#         output = torch.matmul(adj.to(self.device), support)
#
#         return output




class GCN_Layer(torch.nn.Module):
    def __init__(self):
        super(GCN_Layer, self).__init__()
        self.device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")


    def forward(self, input, adj):
        output = torch.matmul(adj.to(self.device), input)

        return output









