import torch
from MCG_STNet.global_views import SoftClustering
from MCG_STNet.gcn import sym_norm_adj, GCN_Layer
from MCG_STNet.cross_views import CrossView
from MCG_STNet.utils import Sparsemax
import math
import torch.nn.functional as F
Tensor = torch.Tensor

import os
os.environ['CUDA_VISIBLE_DEVICES'] = '1'

class GRUCell(torch.nn.Module):
    def __init__(self, hidden_size, input_size, station_num, num_clusters, num_rules):
        super(GRUCell, self).__init__()

        self.device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        self.hidden_size = hidden_size
        self.input_size = input_size
        self.station_num = station_num
        self.num_clusters = num_clusters
        self.num_rules = num_rules

        self.sc = SoftClustering(input_size, num_rules, num_clusters)
        self.batch_norm = torch.nn.BatchNorm2d(1)

        self.sparsemax = Sparsemax()

        self.gcn_layer1_global = GCN_Layer()
        self.gcn_layer2_global = GCN_Layer()
        self.gcn_layer3_global = GCN_Layer()

        self.fc_global_layer0 = torch.nn.Linear(self.num_clusters, self.station_num)
        self.fc_global_layer1 = torch.nn.Linear(self.num_clusters, self.station_num)
        self.fc_global_layer2 = torch.nn.Linear(self.num_clusters, self.station_num)
        # self.fc_global_layer3 = torch.nn.Linear(self.num_clusters, self.station_num)

        self.gcn_layer1_local = GCN_Layer()
        self.gcn_layer2_local = GCN_Layer()
        self.gcn_layer3_local = GCN_Layer()

        self.gcn_layer1_local_global = GCN_Layer()
        self.gcn_layer2_local_global = GCN_Layer()
        self.gcn_layer3_local_global = GCN_Layer()

        self.crossv_layer0 = CrossView(self.input_size)
        self.crossv_layer1 = CrossView(self.input_size)
        self.crossv_layer2 = CrossView(self.input_size)

        self.Wr_global = torch.nn.Linear(self.input_size + self.hidden_size, self.hidden_size, bias=False)
        self.Wz_global = torch.nn.Linear(self.input_size + self.hidden_size, self.hidden_size, bias=False)
        self.Wh_global = torch.nn.Linear(self.input_size + self.hidden_size, self.hidden_size, bias=False)

        self.Wr_local = torch.nn.Linear(self.input_size + self.hidden_size, self.hidden_size, bias=False)
        self.Wz_local = torch.nn.Linear(self.input_size + self.hidden_size, self.hidden_size, bias=False)
        self.Wh_local = torch.nn.Linear(self.input_size + self.hidden_size, self.hidden_size, bias=False)

        self.reset_parameters()


    def reset_parameters(self):
        for weight in self.parameters():
            stdv = 1. / math.sqrt(weight.size(0))
            torch.nn.init.uniform_(weight, -stdv, stdv)


    def apply_bn(self, x):
        # Batch normalization of 3D tensor x
        bn_module = torch.nn.BatchNorm1d(x.size()[1]).to(self.device)
        x = bn_module(x)
        return x

    def apply_bn_ag(self, x):
        x = x.unsqueeze(1)
        x = self.batch_norm(x)
        x = x.squeeze(1)
        return x.mean(dim=0)


    def forward(self, x1, x2, adj_local, hidden_global, hidden_local):

        # global
        global_input_ = self.sc(x1) # B * N * K
        global_input = torch.matmul(global_input_.permute(0, 2, 1), x1) # B * K * D
        # print(global_input.shape)
        global_input = self.apply_bn(global_input)
        S_ = torch.matmul(global_input_.permute(0, 2, 1), adj_local)
        S = torch.matmul(S_, global_input_) # B * K * K
        # S = torch.matmul(torch.matmul(global_input_.permute(0, 2, 1), adj_local), global_input_) # B * K * K
        S = F.softmax(self.apply_bn_ag(S), dim=-1)
        global_input_bn = self.apply_bn_ag(global_input)

        adj_global = self.sparsemax(S * torch.mm(global_input_bn, global_input_bn.permute(1, 0)))

        adj_global = torch.where(adj_global != 0, torch.tensor(1), torch.tensor(0)).fill_diagonal_(0)
        adj_global = sym_norm_adj(adj_global.float())


        x_Gconv1_global = self.gcn_layer1_global(global_input, adj_global.to(self.device))
        x_Gconv1_global_resnet = F.relu(global_input + x_Gconv1_global)
        x_Gconv2_global = self.gcn_layer2_global(x_Gconv1_global_resnet, adj_global.to(self.device))
        x_Gconv2_global_resnet = F.relu(x_Gconv1_global_resnet + x_Gconv2_global)
        x_Gconv3_global = self.gcn_layer3_global(x_Gconv2_global_resnet, adj_global.to(self.device))
        x_Gconv3_global_resnet = F.relu(x_Gconv2_global_resnet + x_Gconv3_global)

        x_global_layer0 = self.fc_global_layer0(global_input.permute(0, 2, 1))
        x_global_layer0 = x_global_layer0.permute(0, 2, 1)
        x_global_layer1 = self.fc_global_layer1(x_Gconv1_global_resnet.permute(0, 2, 1))
        x_global_layer1 = x_global_layer1.permute(0, 2, 1)
        x_global_layer2 = self.fc_global_layer2(x_Gconv2_global_resnet.permute(0, 2, 1))
        x_global_layer2 = x_global_layer2.permute(0, 2, 1)

        x_Gconv_global = x_Gconv1_global_resnet + x_Gconv2_global_resnet + x_Gconv3_global_resnet


        # local
        adj_local = sym_norm_adj(adj_local)

        # local Layers
        x_Gconv1_local = self.gcn_layer1_local(x2, adj_local.to(self.device))
        x_Gconv1_local_resnet = F.relu(x2 + x_Gconv1_local)
        x_Gconv2_local = self.gcn_layer2_local(x_Gconv1_local_resnet, adj_local.to(self.device))
        x_Gconv2_local_resnet = F.relu(x_Gconv1_local_resnet + x_Gconv2_local)
        x_Gconv3_local = self.gcn_layer3_local(x_Gconv2_local_resnet, adj_local.to(self.device))
        x_Gconv3_local_resnet = F.relu(x_Gconv2_local_resnet + x_Gconv3_local)

        x_local_layer0 = torch.cat([x_global_layer0, x2, x_Gconv1_local], dim=-1)
        gama0 = self.crossv_layer0(x_local_layer0)
        local_input_layer0_global = torch.tanh(x2) * gama0 + x_global_layer0 * (1 - gama0)
        x_Gconv1_local_global = self.gcn_layer1_local_global(local_input_layer0_global, adj_local.to(self.device))
        x_Gconv1_local_global_resnet = F.relu(local_input_layer0_global + x_Gconv1_local_global)

        x_local_layer1 = torch.cat([x_global_layer1, x_Gconv1_local_global_resnet, x_Gconv2_local], dim=-1)
        gama1 = self.crossv_layer1(x_local_layer1)
        local_input_layer1_global = torch.tanh(x_Gconv1_local_global_resnet) * gama1 + x_global_layer1 * (1 - gama1)
        x_Gconv2_local_global = self.gcn_layer2_local_global(local_input_layer1_global, adj_local.to(self.device))
        x_Gconv2_local_global_resnet = F.relu(local_input_layer1_global + x_Gconv2_local_global)

        x_local_layer2 = torch.cat([x_global_layer2, x_Gconv2_local_global_resnet, x_Gconv3_local], dim=-1)
        gama2 = self.crossv_layer2(x_local_layer2)
        local_input_layer2_global = torch.tanh(x_Gconv2_local_global_resnet) * gama2 + x_global_layer2 * (1 - gama2)
        x_Gconv3_local_global = self.gcn_layer3_local_global(local_input_layer2_global, adj_local.to(self.device))
        x_Gconv3_local_global_resnet = F.relu(local_input_layer2_global + x_Gconv3_local_global)

        x_Gconv_local = x_Gconv1_local_global_resnet + x_Gconv2_local_global_resnet + x_Gconv3_local_global_resnet


        # GRUs
        x_out_global = torch.cat([x_Gconv_global, hidden_global.to(self.device)], dim=2)
        r_out_global = torch.sigmoid(self.Wr_global(x_out_global))
        z_out_global = torch.sigmoid(self.Wz_global(x_out_global))
        x2_out_global = torch.cat([r_out_global * hidden_global.to(self.device), x_Gconv_global], dim=2)
        h_out_global = torch.tanh(self.Wh_global(x2_out_global))
        h_out_global = (1 - z_out_global) * hidden_global.to(self.device) + z_out_global * h_out_global

        x_out_local = torch.cat([x_Gconv_local, hidden_local.to(self.device)], dim=2)
        r_out_local = torch.sigmoid(self.Wr_local(x_out_local))
        z_out_local = torch.sigmoid(self.Wz_local(x_out_local))
        x2_out_local = torch.cat([r_out_local * hidden_local.to(self.device), x_Gconv_local], dim=2)
        h_out_local = torch.tanh(self.Wh_local(x2_out_local))
        h_out_local = (1 - z_out_local) * hidden_local.to(self.device) + z_out_local * h_out_local


        del adj_local, global_input_, global_input, adj_global, x_Gconv1_global,\
            x_Gconv1_global_resnet, x_Gconv2_global, x_Gconv2_global_resnet, x_Gconv3_global, x_Gconv3_global_resnet, \
            x_global_layer0, x_global_layer1, x_global_layer2, x_Gconv_global, x_Gconv1_local, \
            x_Gconv1_local_resnet, x_Gconv2_local, x_Gconv2_local_resnet, x_Gconv3_local, x_Gconv3_local_resnet, \
            x_local_layer0, gama0, local_input_layer0_global, x_Gconv1_local_global, x_Gconv1_local_global_resnet, \
            x_local_layer1, gama1, local_input_layer1_global, x_Gconv2_local_global, x_Gconv2_local_global_resnet, \
            x_local_layer2, gama2, local_input_layer2_global, x_Gconv3_local_global, x_Gconv3_local_global_resnet, \
            x_out_global, r_out_global, z_out_global, x2_out_global, x_out_local, r_out_local, z_out_local, x2_out_local

        return h_out_global, h_out_local