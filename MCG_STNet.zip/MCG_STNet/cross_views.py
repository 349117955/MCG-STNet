import torch
import os
import math
os.environ['CUDA_VISIBLE_DEVICES'] = '1'

class CrossView(torch.nn.Module):
    def __init__(self, station_dim):
        super(CrossView, self).__init__()

        self.device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        self.station_dim = station_dim
        self.linear = torch.nn.Linear(station_dim * 3, station_dim).to(self.device)

        self.reset_parameters()

    def reset_parameters(self):
        for weight in self.parameters():
            stdv = 1. / math.sqrt(weight.size(0))
            torch.nn.init.uniform_(weight, -stdv, stdv)


    def forward(self, x):
        fnn_input_x = self.linear(x)
        gama = torch.sigmoid(fnn_input_x)

        del fnn_input_x

        return gama