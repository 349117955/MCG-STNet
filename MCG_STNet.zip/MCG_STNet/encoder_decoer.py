import torch
import math
from MCG_STNet.gru_cell import GRUCell
from MCG_STNet.utils import Attention
import random



class Encoder_Decoder(torch.nn.Module):
    def __init__(self):
        super(Encoder_Decoder, self).__init__()
        self.device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        self.hidden_size = 64
        self.forecast = 6
        self.stations = 13
        self.input_size = 24
        self.num_clusters = 8
        self.num_rules = 1
        self.Wt = torch.nn.Parameter(torch.FloatTensor(self.hidden_size, self.hidden_size))
        self.Wt_ = torch.nn.Parameter(torch.FloatTensor(self.hidden_size, self.hidden_size))
        self.bt = torch.nn.Parameter(torch.FloatTensor(self.hidden_size))
        self.vt = torch.nn.Parameter(torch.FloatTensor(self.hidden_size))
        self.wglobal = torch.nn.Parameter(torch.FloatTensor(self.hidden_size))
        self.wlocal = torch.nn.Parameter(torch.FloatTensor(self.hidden_size))
        self.bfc = torch.nn.Parameter(torch.FloatTensor(self.stations))
        self.att = Attention(self.hidden_size, 32)
        self.dfc = torch.nn.Linear(self.num_clusters, self.stations)
        self.dfc2 = torch.nn.Linear(self.stations, self.num_clusters)
        self.dfc3 = torch.nn.Linear(self.num_clusters, self.stations)
        self.dfc4 = torch.nn.Linear(self.stations, self.num_clusters)
        self.dfc5 = torch.nn.Linear(self.num_clusters, self.stations)
        self.cell1 = GRUCell(self.hidden_size, self.input_size, self.stations, self.num_clusters, self.num_rules)
        # self.cell2 = GRUCell(self.hidden_size, self.hidden_size, self.stations, self.num_clusters, self.num_rules)
        self.dcell = GRUCell(self.hidden_size, self.hidden_size, self.stations, self.num_clusters, self.num_rules)
        self.reset_parameters()


    def reset_parameters(self):
        for weight in self.parameters():
            stdv = 1. / math.sqrt(weight.size(0))
            torch.nn.init.uniform_(weight, -stdv, stdv)


    def input_transform(self, x):
        local_inputs, labels = x
        #  16, 12, 34, 26      16, 6, 1, 26
        local_inputs = local_inputs.permute(1, 0, 2, 3)  # (12h, batch, feature, stations)
        labels = labels.permute(1, 0, 2, 3)  # (6h, batch, 1features, stations)
        n_input_encoder = local_inputs.data.size(2)  # 28features
        batch_size = local_inputs.data.size(1)
        _local_inputs = local_inputs.contiguous().view(-1, n_input_encoder, self.stations)
        _local_inputs = torch.split(_local_inputs, batch_size, 0)
        encoder_inputs = _local_inputs
        _labels = labels.contiguous().view(-1, self.stations)
        _labels = torch.split(_labels, batch_size, 0)  # （batch, 1, stations）
        _lastinp = local_inputs[11:12, :, 0:1, :]  # 1, 256, 1, 35
        _lastinp = _lastinp.contiguous().view(-1, 1, self.stations)
        _lastinp = torch.split(_lastinp, batch_size, 0)
        decoder_inputs = list(_lastinp) + list(_labels[:-1])  # 6*(256, 1, 35)

        del local_inputs, labels, n_input_encoder, batch_size, _local_inputs, _lastinp

        return encoder_inputs, _labels, decoder_inputs


    def Encoder(self, encoder_inputs, As):
        Inputs = encoder_inputs  # 12 (batch, feature, stations)
        batch_size = Inputs[0].data.size(0)
        stations = Inputs[0].data.size(2)

        lasth_hidden_global = torch.rand(batch_size, self.num_clusters, self.hidden_size)
        lasth_hidden_local = torch.rand(batch_size, stations, self.hidden_size)

        hlist_global = []
        hlist_local = []

        for flinput in Inputs:
            flinputx = flinput.permute(0, 2, 1)  # stations, feature,
            flinputx = torch.as_tensor(flinputx, dtype=torch.float32).to(self.device)

            h1_global, h1_local = self.cell1(flinputx, flinputx, As, lasth_hidden_global, lasth_hidden_local)
            # h2_global, h2_local = self.cell2(h1_global, h1_local, As, lasth_hidden_global, lasth_hidden_local)
            lasth_hidden_global = h1_global
            lasth_hidden_local = h1_local
            hlist_global.append(h1_global)
            hlist_local.append(h1_local)

        del Inputs, batch_size, stations, lasth_hidden_global, lasth_hidden_local

        return hlist_global, hlist_local



    def Decoder(self, As, decoder_inputs, encoder_inputs, hlist_global, hlist_local, teather_ratio):
        Inputs = encoder_inputs
        batch_size = Inputs[0].data.size(0)
        stations = Inputs[0].data.size(2)
        lasthd_global = torch.rand(batch_size, self.num_clusters, self.hidden_size)
        lasthd_local = torch.rand(batch_size, stations, self.hidden_size)

        predicts = []

        for dint in decoder_inputs:
            etlist = []
            for h_global, h_local in zip(hlist_global, hlist_local):
                h_global_ = self.dfc(h_global.permute(0, 2, 1))
                h_global_ = h_global_.permute(0, 2, 1)
                et = torch.stack([h_global_, h_local], dim=1)
                et, _ = self.att(et)
                etlist.append(et)

            sumalfa1 = torch.zeros(batch_size, self.num_clusters, self.hidden_size).to(self.device)
            alfalist1 = []
            for et in etlist:
                et_ = self.dfc2(et.permute(0, 2, 1))
                et_ = et_.permute(0, 2, 1)

                alfa = torch.matmul(torch.tanh(
                    torch.matmul(et_.to(self.device), self.Wt) + torch.matmul(lasthd_global.to(self.device),
                                                                                 self.Wt_) + self.bt), self.vt)
                alfa = alfa.reshape(batch_size, -1, 1)
                alfalist1.append(torch.exp(alfa))
                sumalfa1 = sumalfa1 + torch.exp(alfa)
            C1 = torch.zeros(batch_size, self.num_clusters, self.hidden_size).to(self.device)
            for et, alfa in zip(etlist, alfalist1):
                et_ = self.dfc2(et.permute(0, 2, 1))
                et_ = et_.permute(0, 2, 1)
                alfa = torch.div(alfa, sumalfa1)
                C1 = C1 + alfa * et_

            sumalfa2 = torch.zeros(batch_size, stations, self.hidden_size).to(self.device)
            alfalist2 = []
            for et in etlist:
                alfa = torch.matmul(torch.tanh(
                    torch.matmul(et.to(self.device), self.Wt) + torch.matmul(lasthd_local.to(self.device),
                                                                             self.Wt_) + self.bt), self.vt)
                alfa = alfa.reshape(batch_size, -1, 1)
                alfalist2.append(torch.exp(alfa))
                sumalfa2 = sumalfa2 + torch.exp(alfa)
            C2 = torch.zeros(batch_size, stations, self.hidden_size).to(self.device)
            for et, alfa in zip(etlist, alfalist2):
                alfa = torch.div(alfa, sumalfa2)
                C2 = C2 + alfa * et


            ran_t = random.random()
            is_teather = ran_t < teather_ratio
            dint1 = self.dfc4(dint)
            dint1 = dint1.reshape(batch_size, self.num_clusters, 1).float().repeat(1, 1, self.hidden_size)
            dint = dint.reshape(batch_size, self.stations, 1).float().repeat(1, 1, self.hidden_size)
            C1 = (dint1 if is_teather else C1)
            C2 = (dint if is_teather else C2)


            C1 = self.dfc5(C1.permute(0, 2, 1))
            C1 = C1.permute(0, 2, 1)
            d_global, d_local = self.dcell(C1, C2, As, lasthd_global, lasthd_local)
            lasthd_global = d_global
            lasthd_local = d_local
            d_global__ = self.dfc3(d_global.permute(0, 2, 1))
            d_global__ = d_global__.permute(0, 2, 1)
            ypredict = torch.tanh(torch.matmul(d_global__, self.wglobal) + torch.matmul(d_local, self.wlocal))
            predicts.append(ypredict)

        del lasthd_global, lasthd_local

        return predicts


    def forward(self, x, As, teather_ratio):
        encoder_inputs, labels, decoder_inputs = self.input_transform(x)
        hlist_global, hlist_local = self.Encoder(encoder_inputs, As)
        predicts = self.Decoder(As, decoder_inputs, encoder_inputs, hlist_global, hlist_local, teather_ratio)

        del encoder_inputs, decoder_inputs, hlist_global, hlist_local

        return predicts, labels

