import torch
import numpy as np
from math import radians, cos, sin, asin
from math import sqrt
import os


os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'


# 关系图构建
def RGC():
    def calDistance(lat1, lng1, lat2, lng2):
        lng1, lat1, lng2, lat2 = map(radians, [float(lng1), float(lat1), float(lng2), float(lat2)])  # 经纬度转换成弧度
        dlon = lng2 - lng1
        dlat = lat2 - lat1
        a = sin(dlat / 2) ** 2 + cos(lat1) * cos(lat2) * sin(dlon / 2) ** 2
        distances = 2 * asin(sqrt(a)) * 6371 * 1000  # 地球平均半径，6371km
        distance = round(distances / 1000, 3)
        return distance

    def SPAdj():
        # ----------------Spatial adjacency-------------
        sigma = 7.2944
        dist_adj = []
        for line in open("station_loc.txt", encoding='utf-8'):  # 设置文件对象并读取每一行文件
            array = line.split(',')
            station_lng = array[2]
            station_lat = array[1]
            dist_ = []
            for line in open("station_loc.txt", encoding='utf-8'):  # 设置文件对象并读取每一行文件
                array = line.split(',')
                station_lng1 = array[2]
                station_lat1 = array[1]
                dist = calDistance(station_lat1, station_lng1, station_lat, station_lng)
                if dist > 10:
                    dist = 0
                else:
                    dist = np.exp(-(dist ** 2) / sigma ** 2)
                dist_.append(dist)
            dist_adj.append(dist_)
        kernel = torch.FloatTensor(dist_adj)
        # 去掉自环，并且转换0,1矩阵
        kernel = torch.where(kernel != 0, torch.tensor(1), torch.tensor(0)).fill_diagonal_(0)
        return kernel.float()


    As = SPAdj()

    return As





