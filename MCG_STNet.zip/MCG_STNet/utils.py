import torch
import torch.nn.functional as F
Tensor = torch.Tensor

import os
os.environ['CUDA_VISIBLE_DEVICES'] = '1'



class Attention(torch.nn.Module):
    def __init__(self, in_size, hidden_size):
        super(Attention, self).__init__()

        self.project = torch.nn.Sequential(
            torch.nn.Linear(in_size, hidden_size),
            torch.nn.Tanh(),
            torch.nn.Linear(hidden_size, 1, bias=False)
        )

    def forward(self, z):
        w = self.project(z)
        beta = torch.nn.functional.softmax(w, dim=1)

        return (beta * z).sum(1), beta


class Sparsemax(torch.nn.Module):
    def __init__(self):
        super(Sparsemax, self).__init__()

    def forward(self, input):
        sorted_input, _ = torch.sort(input, dim=-1, descending=True)
        cumsum_input = torch.cumsum(sorted_input, dim=-1)
        k = torch.arange(1, input.size(-1) + 1, device=input.device)
        k_z = 1 + k * sorted_input > cumsum_input
        k_z = k_z.sum(dim=-1, keepdim=True)
        k_z = k_z.to(input.dtype)
        tau = (cumsum_input.gather(-1, (k_z - 1).long()) - 1) / k_z
        output = torch.clamp(input - tau, min=0)
        return output

