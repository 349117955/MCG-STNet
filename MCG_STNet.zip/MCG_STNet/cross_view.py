import torch
import os
import math
Tensor = torch.Tensor

os.environ['CUDA_VISIBLE_DEVICES'] = '1'


class GaussianMembershipFunction(torch.nn.Module):
    def __init__(self, in_features, out_features):
        super(GaussianMembershipFunction, self).__init__()
        self.centers = torch.nn.Parameter(torch.randn(out_features, in_features))
        self.sigmas = torch.nn.Parameter(torch.randn(out_features, in_features))
        self.reset_parameters()

    def reset_parameters(self):
        for weight in self.parameters():
            stdv = 1. / math.sqrt(weight.size(0))
            torch.nn.init.uniform_(weight, -stdv, stdv)

    def forward(self, x):
        num = (x.unsqueeze(2) - self.centers) ** 2
        denom = 2 * (self.sigmas ** 2)
        gauss = torch.exp(-num / denom)
        del num, denom
        return gauss



class FuzzyRuleLayer(torch.nn.Module):
    def __init__(self, input_dim, num_rules):
        super(FuzzyRuleLayer, self).__init__()
        self.fuzzify = GaussianMembershipFunction(input_dim, num_rules)

    def forward(self, x):
        x = self.fuzzify(x)
        weights = torch.nn.functional.softmax(x, dim=2)
        return torch.sum(weights * x, dim=2)



class CrossView(torch.nn.Module):
    def __init__(self, station_dim, num_rules):
        super(CrossView, self).__init__()

        self.device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        self.station_dim = station_dim
        self.fnn = FuzzyRuleLayer(station_dim * 3, num_rules)
        self.linear = torch.nn.Linear(station_dim * 3, station_dim).to(self.device)

        self.reset_parameters()

    def reset_parameters(self):
        for weight in self.parameters():
            stdv = 1. / math.sqrt(weight.size(0))
            torch.nn.init.uniform_(weight, -stdv, stdv)

    def forward(self, x):
        # FNN feature
        fnn_input_x = self.linear(self.fnn(x))
        gama = torch.sigmoid(fnn_input_x)

        del fnn_input_x

        return gama