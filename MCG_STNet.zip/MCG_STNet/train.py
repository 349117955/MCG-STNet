import numpy as np
import torch.optim as optim
import torch
import random
import matplotlib.pyplot as plt
import math
import datetime
from MCG_STNet.earlystopping import EarlyStopping
from MCG_STNet.encoder_decoer import Encoder_Decoder
from MCG_STNet.utils_graph import RGC
import os


os.environ["KMP_DUPLICATE_LIB_OK"]="TRUE"


def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

set_seed(2024)

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
model = Encoder_Decoder()
model.to(device)

print('开始时间-------', datetime.datetime.now())
total_epoch = 500
# total_epoch = 2
batch_size = 256
# lr = 0.001
lr = 0.001
traindata = np.load("Data/trainlondon.npy")
testdata = np.load("Data/testlondon.npy")
pm25_train = np.load("Data/train_pm25.npy")
pm25_test = np.load("Data/test_pm25.npy")
max_value = 189.7
min_value = 0
# optimizer = optim.Adam(model.parameters(), lr=lr, betas=(0.9, 0.999), eps=1e-08, weight_decay=1e-6)
# optimizer = optim.Adam(model.parameters(), lr=lr, betas=(0.9, 0.999), eps=1e-08, weight_decay=0.01)
optimizer = optim.Adam(model.parameters(), lr=lr, betas=(0.9, 0.999), eps=1e-08, weight_decay=0)
# scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer,mode='min', factor=0.1, patience=10)
index = [i for i in range(len(testdata))]
random.shuffle(index)
testdata = testdata[index]
pm25_test = pm25_test[index]

def get_batch_feed_dict(k, batch_size, training_data,train_labels_data):
    batch_train_inp = training_data[k:k + batch_size]
    batch_label_inp = train_labels_data[k:k + batch_size]
    feed_dict = (batch_train_inp,batch_label_inp)
    return feed_dict

def criterion(preds, labels):
    loss_fn = torch.nn.MSELoss()
    loss = 0.0
    for ps, ls in zip(preds, labels):
        loss = loss + loss_fn(ps.cpu().float(), ls.cpu().float())
    return loss


num_train = 7975 - 1095
num_valid = 1095
num_test = 1095

train_data = torch.from_numpy(traindata[:num_train, :, :, :]).float().to(device)  # 6990, 12, 34, 26
train_labels_data = torch.from_numpy(pm25_train[:num_train, :, :, :]).float().to(device)  # 6990, 6, 1, 26

valid_data = torch.from_numpy(traindata[num_train:, :, :, :]).float().to(device)
valid_labels_data = torch.from_numpy(pm25_train[num_train:, :, :]).float().to(device)

test_data = torch.from_numpy(testdata[:, :, :, :]).float().to(device)
test_labels_data = torch.from_numpy(pm25_test[:, :, :]).float().to(device)

train_losses = []
valid_losses = []
avg_train_losses = []
avg_valid_losses = []

early_stopping = EarlyStopping(patience=15, verbose=True)

teather_ratio = 0.5
# teather_ratio = 0.0
As = RGC()
te = 0.0




for i in range(total_epoch):
    print('----------epoch {}-----------{}'.format(i, datetime.datetime.now()))
    i += 1
    teather_ratio = teather_ratio * (0.3 ** (i // 30))
    for j in range(0, num_train, batch_size):
        x = get_batch_feed_dict(j, batch_size, train_data, train_labels_data)
        preds, labels = model(x, As, teather_ratio)

        optimizer.zero_grad()

        preds_loss = criterion(preds, labels)

        loss = preds_loss

        loss.backward(retain_graph=True)

        optimizer.step()

        train_losses.append(loss.item())

    for j in range(0, num_valid, batch_size):
        x = get_batch_feed_dict(j, batch_size, valid_data, valid_labels_data)
        preds, labels = model(x, As, te)

        preds_loss = criterion(preds, labels)

        loss = preds_loss

        valid_losses.append(loss.item())

    train_loss = np.average(train_losses)
    valid_loss = np.average(valid_losses)
    avg_train_losses.append(train_loss)
    avg_valid_losses.append(valid_loss)

    early_stopping(valid_loss, model)
    print_msg = (' train_loss:' + str(train_loss) + ' valid_loss:' + str(valid_loss))
    print(print_msg)
    if early_stopping.early_stop:
        print("Early stopping")
        break

fig = plt.figure(figsize=(10, 8))
plt.plot(range(1, len(avg_train_losses) + 1), avg_train_losses, label='Training Loss')
plt.plot(range(1, len(avg_valid_losses) + 1), avg_valid_losses, label='Validation Loss')
minposs = avg_valid_losses.index(min(avg_valid_losses)) + 1
plt.axvline(minposs, linestyle='--', color='r', label='Early Stopping Checkpoint')

plt.xlabel('epochs')
plt.ylabel('loss')
plt.grid(True)
plt.legend()
plt.tight_layout()
plt.show()
fig.savefig('loss_plot.png', bbox_inches='tight')


def MAEloss(preds, labels):
    loss_fn = torch.nn.L1Loss()
    loss = 0.0
    for ps, ls in zip(preds, labels):
        loss = loss + loss_fn(ps.cpu().float() * (max_value - min_value) + min_value,
                              ls.cpu().float() * (max_value - min_value) + min_value)
    return loss


def RMSEloss(preds, labels)                                                                                                                                                                   :
    loss_fn = torch.nn.MSELoss()
    loss = 0.0
    for ps, ls in zip(preds, labels):
        loss = loss + loss_fn(ps.cpu().float() * (max_value - min_value) + min_value,
                              ls.cpu().float() * (max_value - min_value) + min_value)
    return loss


def MAPEloss(preds, labels, null_val = np.nan):
    def loss_fn(preds, labels, null_val):
        if np.isnan(null_val):
            mask = ~torch.isnan(labels)
        else:
            mask = (labels != null_val)
        mask = mask.float()
        mask /= torch.mean((mask))
        mask = torch.where(torch.isnan(mask), torch.zeros_like(mask), mask)
        diff = torch.abs(labels - preds)/labels
        diff = diff * mask
        diff = torch.where(torch.isnan(diff), torch.zeros_like(diff), diff)
        return torch.mean(diff)
    loss = 0.0
    for ps, ls in zip(preds, labels):
        loss = loss + loss_fn(ps.float() * (max_value - min_value) + min_value,
                              ls.float() * (max_value - min_value) + min_value, 0.0)
    return loss


rmses = []
maes = []
mapes = []
test_loss = []
test_loss1 = []
test_loss2 = []

for k in range(0, num_test, batch_size):
    teather_ratio = 0
    x = get_batch_feed_dict(k, batch_size, test_data, test_labels_data)
    preds, labels = model(x, As, teather_ratio)
    loss = RMSEloss(preds, labels) / 6
    loss1 = MAEloss(preds, labels) / 6
    loss2 = MAPEloss(preds, labels) / 6
    test_loss.append(loss.item())
    test_loss1.append(loss1.item())
    test_loss2.append(loss2.item())

print('===============METRIC===============')
MAE = np.average(test_loss1)
mseLoss = math.sqrt(np.average(test_loss))
MAPE = np.average(test_loss2) * 100
print('MAE = {:.6f}'.format(MAE))
print('RMSE = {:.6f}'.format(mseLoss))
print('MAPE = {:.6f}'.format(MAPE))

